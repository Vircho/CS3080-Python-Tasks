from django.urls import path
from . import views

urlpatterns = [
    path('', views.get_user_info, name = 'user_info'),
    path('weather/',views.show_weather,name='show_weather'),
]