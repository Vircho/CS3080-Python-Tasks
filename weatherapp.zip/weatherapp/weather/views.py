from django.shortcuts import render, HttpResponse, redirect
from .forms import LocationForm
import requests

#Constants
API = '9c1de47da89283a158f13738ca00f3f0'    #WeatherAPI key to access data

# I am pretty sure this is where I do the web scraping to get the information

def get_user_info(request):
    #g et the form
    form = LocationForm(request.POST)
    # when form is submited
    if form.is_valid():
        # get the values from the form 
        # then redirect the session to the show weather portion
        request.session['user_data'] = form.cleaned_data
        return redirect('show_weather')
    # if not valid re show the form
    return render(request, 'user_form.html',{'form':form})


def show_weather(request):

    # data is a dictonary of the user data from the request session
    data = request.session.get('user_data')
    # if there is no data the session is redirected back to the form
    if not data:
        return redirect('user_info')
    
    city = data['city']
    state = data['state']
    country = data['country']

    #Common other typings of US
    if country.lower() == 'usa':
        country = 'US'
    elif country.lower() == 'united states':
        country = 'US'
    elif country.lower() == 'united states of america':
        country = 'US'

    #geocoding link - uses a city/state/country name to get latitude/longitude
    geo_link = create_link_geo(city, state, country, API)

    #Request from the geocoding link
    res_geo = requests.get(geo_link)
    geocoding_json = res_geo.json()[0]    #I need [0] because .json returns a dictionary containing the stuff i want inside a list

    #Get the latitude and longitude of the city
    lat = geocoding_json['lat']
    lon = geocoding_json['lon']

    #Get link for current weather data
    weather_link = create_link_weather(lat, lon, API)
    res_weather = requests.get(weather_link)
    weather_data = res_weather.json()

    #WeatherAPI uses Kelvin by default
    temp_c = str(int(float((weather_data['main'])['temp']) - 273.1))
    temp_f = str(int(float(temp_c) * (9/5) + 32))

    #WeatherAPI doesn't have precipitation in the json file if there is no rain or snow
    try:
        precip = weather_data['rain']
    except KeyError:
        precip = '0'

    try:
        precip += weather_data['snow']
    except KeyError:
        pass

    humid = (weather_data['main'])['humidity']
    wind = (weather_data['wind'])['speed']

    ## return all of the variables to the html file
    return render(request, 'weather_result.html', {
        "temp_c": temp_c,
        "temp_f": temp_f,
        "precipitation": precip,
        "humidity": humid,
        "wind": wind,
        'user':data,
    })

def create_link_geo(city, state, country, api):
    link = (f'http://api.openweathermap.org/geo/1.0/direct?q={city}, '
            f'{state}, {country}&limit=1&appid={API}')
    return link

def create_link_weather(lat, lon, api):
    link = f'https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={API}'
    return link