from django.shortcuts import render, HttpResponse, redirect
from .forms import LocationForm
import requests, bs4

# I am pretty sure this is where I do the web scraping to get the information

def get_user_info(request):
    if request.method == 'POST':
        print('post')
    #g et the form
    form = LocationForm(request.POST)
    # when form is submited
    if form.is_valid():
        # get the values from the form 
        # then redirect the session to the show weather portion
        request.session['user_data'] = form.cleaned_data
        return redirect('show_weather')
    # if not valid re show the form
    else:
        return render(request, 'user_form.html',{'form':form})


def show_weather(request):
    # data is a dictonary of the user data from the request session
    data = request.session.get('user_data')
    # if there is no data the session is redirected back to the form
    if not data:
        return redirect('user_info')
    
    ## do web scraping here
    city = data['city']
    state = data['state']
    country = data['country']

    test_string = f"{city}, {state}, {country} weather"

    # test variables
    # user web scraping to get the value of each variable
    temp_c = 'test tempc'
    temp_f = 'test tempf'
    precip = 'test precip'
    humid = 'test humidity'
    wind = 'test wind'

    ## return all of the variables to the html file
    return render(request, 'weather_result.html', {
        "temp_c": temp_c,
        "temp_f": temp_f,
        "precipitation": precip,
        "humidity": humid,
        "wind": wind,
        'user':data,
    })



